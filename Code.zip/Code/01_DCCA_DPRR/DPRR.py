# -*- coding: utf-8 -*-
"""
Calculation of DPRR based on DCCA and DPCCA.

@author: Li Tongfang
"""

import os
import numpy as np
import pandas as pd
import time
from sklearn.neighbors import KernelDensity
from sklearn.model_selection import GridSearchCV


# cumulative sequence
def seq_accumulate(seq_old):
    N = len(seq_old)
    seq_new = np.zeros(N)
    for i in range(N):
        seq_new[i] = sum(seq_old[:i+1])
    return seq_new

# detrend
def d_trend(seq, order=1):
    y = seq
    n = len(y)
    x = np.arange(n) + 1
    fuction_fit = np.polyfit(x, y,deg = order)
    value_fit = np.polyval(fuction_fit, x)
    output = y - value_fit
    return output


# For the cumulative sequence, 
# divide the subsequence according to the step size for detrending, 
# and return the long sequence after detrending
def d_trend_step(seq, step, order=1):
    seq_acc = seq_accumulate(seq)
    n = len(seq_acc)
    s = step - 1
    seq_new = np.zeros((s+1)*(n-s))
    for i in range(n - s):
        seq_sub = seq_acc[i:i+s+1]
        seq_sub_d_trend = d_trend(seq_sub,order)
        seq_new[((s+1)*i):(s+1)*(i+1)] = seq_sub_d_trend
    return seq_new

#------------------------------------------------------------------
# # calculate DCCA
def DCCA_c(seq_x,seq_y):    # The input is the accumulated detrended sequence
    N = len(seq_x)
    fxx = (sum(seq_x * seq_x) / N) ** 0.5
    fyy = (sum(seq_y * seq_y) / N) ** 0.5
    Fxy = sum(seq_x * seq_y) / N
    output = Fxy / (fxx * fyy)
    return output

# calculate DPCCA
def DPCCA_c(seq_long_0,seq_long_1,seq_long_2):  # The input is the accumulated detrended sequence
    DCCA_matrix = np.full((3,3),1.)
    DCCA_matrix[0,1] = DCCA_c(seq_long_0,seq_long_1)
    DCCA_matrix[1,0] = DCCA_matrix[0,1]
    DCCA_matrix[0,2] = DCCA_c(seq_long_0,seq_long_2)
    DCCA_matrix[2,0] = DCCA_matrix[0,2]
    DCCA_matrix[1,2] = DCCA_c(seq_long_1,seq_long_2)
    DCCA_matrix[2,1] = DCCA_matrix[1,2]
    matrix_pinv = np.linalg.pinv(DCCA_matrix)
    result = (-1 * matrix_pinv[0,1])/((matrix_pinv[0,0] * matrix_pinv[1,1]) ** 0.5)
    return result

# -----------------------------------------------------
# kernel density
def kernel_density(data):
    data = np.array(data)
    data = data[:,None]
                
    bandwidth = np.arange(0.05, 2, .05)
    kde = KernelDensity(kernel='gaussian')
    grid = GridSearchCV(kde, {'bandwidth': bandwidth})
    grid.fit(data)
    
    kde = grid.best_estimator_
    log_dens = kde.score_samples(data)
    dens = np.exp(log_dens)
    ind_max = np.where(dens == np.max(dens))
    return data[ind_max]

#--------------------------------Extract three time series overlapping periods----------------------------
def extract_same_time(series_1,series_2,series_3): #Input 2-dimensional (1 column) dataframe, output 1-dimensional array
    series_1_index = series_1.index
    series_2_index = series_2.index
    series_3_index = series_3.index
    
    series_01 = series_1[series_1_index.isin(series_2_index)]
    series_02 = series_2[series_2_index.isin(series_1_index)]
    
    series_01_index = series_01.index
    series_02_index = series_02.index
    
    array_1 = series_01[series_01_index.isin(series_3_index)].values.flatten()
    array_2 = series_02[series_02_index.isin(series_3_index)].values.flatten()
    array_3 = series_3[series_3_index.isin(series_01_index)].values.flatten()
    
    return array_1,array_2,array_3

# -----------------------------------------------
def DPRR(series_0,series_1,series_2,step_min = 12,order = 1):
    seq_0,seq_1,seq_2 = extract_same_time(series_0,series_1,series_2)
    N = len(seq_0)
    step_max = N-1
    
    step_series = [];dcca_series = [];dpcca_series = [];dprr_series = []
    
    dcca_dpcca = pd.DataFrame(columns = ['step','DCCA','DPCCA'])
    
    dprr = pd.DataFrame(columns = ['step','DPRR'])
    
    dcca_dpcca_dprr = pd.DataFrame(columns = ['step','DCCA','DPCCA','DPRR'])
    for step in range(step_min, step_max + 1):
        seq_0_long = d_trend_step(seq_0,step,order)
        seq_1_long = d_trend_step(seq_1,step,order)
        seq_2_long = d_trend_step(seq_2,step,order)
        dcca_c = DCCA_c(seq_0_long,seq_1_long)
        dpcca_c = DPCCA_c(seq_0_long,seq_1_long,seq_2_long)

        step_series.append(step)
        dcca_series.append(dcca_c)
        dpcca_series.append(dpcca_c)
        dprr_series.append((dcca_c-dpcca_c)/(dcca_c + 1))
        
    dprr_kde_max = kernel_density(dprr_series)
    
    dcca_dpcca['step'] = step_series;
    dcca_dpcca['DCCA'] = dcca_series;
    dcca_dpcca['DPCCA'] = dpcca_series
    dprr['step'] = step_series; dprr['DPRR'] = dprr_series
    dcca_dpcca_dprr['step'] = step_series; dcca_dpcca_dprr['DCCA'] = dcca_series
    dcca_dpcca_dprr['DPCCA'] = dpcca_series; dcca_dpcca_dprr['DPRR'] = dprr_series;
    return dcca_dpcca_dprr,dprr_kde_max
    


if __name__ == "__main__":
    rootpath = r'F:\DCCA、DPCA\04-six-factors'
    stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
    factorlst = ['et0','bf','ndvi','isr','ntl','pop']
    dprr_kde_max_matrix = pd.DataFrame(index = stationlst,columns = factorlst)
    
    start = time.time()
    for station in stationlst:

        meteo = pd.read_excel(os.path.join(rootpath,r'01-data\01-meteorological_data\{}_meteo.xlsx'.format(station)),
                                sheet_name = 'monthly',header = 0,index_col = 0)
        pre = meteo[['precipitation']]
        et0 = meteo[['ET0']]
        runoff = pd.read_excel(os.path.join(rootpath,r'01-data\02-runoff\{}_runoff.xlsx'.format(station)),
                                sheet_name = 'monthly',header = 0,index_col = 0)
        bf = pd.read_excel(os.path.join(rootpath,r'01-data\03-baseflow\{}_baseflow.xlsx'.format(station)),
                               sheet_name = 'monthly',header = 0,index_col = 0)
        ndvi = pd.read_excel(os.path.join(rootpath,r'01-data\04-NDVI\{}_NDVI.xlsx'.format(station)),
                               sheet_name = 'monthly',header = 0,index_col = 0)
        isr = pd.read_excel(os.path.join(rootpath,r'01-data\05-ISR\ISR.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        ntl = pd.read_excel(os.path.join(rootpath,r'01-data\06-NTL\NTL.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        pop = pd.read_excel(os.path.join(rootpath,r'01-data\07-POP\POP.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        sheet_count = 1
        for factor_index in range(len(factorlst)):
            factor = factorlst[factor_index]
            factor3 = []
            exec("factor3 = {}".format(factor))    

            dcca_dpcca_dprr,dprr_kde_max = DPRR(pre,runoff,factor3)
            dprr_kde_max_matrix.loc[[station],[factor]] = dprr_kde_max

            if sheet_count == 1:
                with pd.ExcelWriter(os.path.join(rootpath,r'02-DCCA+DPRR\{}_DPRR.xlsx'.format(station))) as writer:
                    dcca_dpcca_dprr.to_excel(writer, sheet_name = factor,index = False)
            else:
                with pd.ExcelWriter(os.path.join(rootpath,r'02-DCCA+DPRR\{}_DPRR.xlsx'.format(station)),
                                    mode="a",engine="openpyxl") as writer:
                    dcca_dpcca_dprr.to_excel(writer, sheet_name = factor, index = False)
            sheet_count += 1
        end = time.time()
        print(station,':',end-start)
                
    with pd.ExcelWriter(os.path.join(rootpath,r'02-DCCA+DPRR\DPRR_kde_max.xlsx')) as writer:
        dprr_kde_max_matrix.to_excel(writer, sheet_name = 'DPRR_kde_max')

    print('ok')
    
    

   
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    










