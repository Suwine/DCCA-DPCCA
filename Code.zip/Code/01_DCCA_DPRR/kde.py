# -*- coding: utf-8 -*-
"""
Calculating the maximum kernel density corresponding value of the series.

@author: Li Tongfang
"""

import os
import numpy as np
import pandas as pd
from sklearn.neighbors import KernelDensity
from sklearn.model_selection import GridSearchCV

def kernel_density(data):
    data = np.array(data)
    data = data.reshape([len(data),1])
                
    bandwidth = np.arange(0.05, 2, .05)
    kde = KernelDensity(kernel='gaussian')
    grid = GridSearchCV(kde, {'bandwidth': bandwidth})
    grid.fit(data)
    
    kde = grid.best_estimator_
    log_dens = kde.score_samples(data)
    dens = np.exp(log_dens)
    ind_max = np.where(dens == np.max(dens))
    return data[ind_max]


rootpath = r'F:\DCCA、DPCA\04-six-factors'
stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
factorlst = ['et0','bf','ndvi','isr','ntl','pop']
methodlst = ['DCCA','DPCCA','DPRR']

sheet_num = 1
for method in methodlst:
    data_kde = pd.DataFrame(index = stationlst,columns = factorlst)
    for station in stationlst:

        for factor in factorlst:
            data = pd.read_excel(os.path.join(rootpath,r'02-DCCA+DPRR\{}_DPRR.xlsx'.format(station)),
                     sheet_name = factor,header = 0,index_col = 0)
            
            data_kde.loc[[station],[factor]] = kernel_density(data[method].iloc[24:])
    if sheet_num == 1:
        with pd.ExcelWriter(os.path.join(rootpath,r'02-DCCA+DPRR\kde_max.xlsx')) as writer:
            data_kde.to_excel(writer, sheet_name = method+'_kde_max')
    else:
        with pd.ExcelWriter(os.path.join(rootpath,r'02-DCCA+DPRR\kde_max.xlsx'),
                            mode = 'a',engine="openpyxl") as writer:
            data_kde.to_excel(writer, sheet_name = method+'_kde_max')
    sheet_num += 1






