# -*- coding: utf-8 -*-

"""
Calculating the D-DPRR results under different step conditions.

@author: Li Tongfang
"""
import os
import numpy as np
import pandas as pd
import time

# cumulative sequence
def seq_accumulate(seq_old):
    N = len(seq_old)
    seq_new = np.zeros(N)
    for i in range(N):
        seq_new[i] = sum(seq_old[:i+1])
    return seq_new

# detrend
def d_trend(seq, order):
    y = seq
    n = len(y)
    x = np.arange(n) + 1
    fuction_fit = np.polyfit(x, y,deg = order)
    value_fit = np.polyval(fuction_fit, x)
    output = y - value_fit
    return output

# For the cumulative sequence,
# divide the subsequence according to the step size for detrending,
# and return the detrended subsequence group
def d_trend_step(seq, step, order=1):
    seq_acc = seq_accumulate(seq)
    n = len(seq_acc)
    s = step - 1
    sub_seq_group = np.zeros([n-s,step])
    for i in range(n - s):
        seq_sub = seq_acc[i:i+s+1]
        seq_sub_d_trend = d_trend(seq_sub,order)
        sub_seq_group[i,:] = seq_sub_d_trend
    return sub_seq_group

#--------------------------------------------
# # calculate DCCA
def DCCA_c(seq_x,seq_y):  # The input is the detrended subsequence
    N = len(seq_x)
    fxx = (sum(seq_x * seq_x) / N) ** 0.5
    fyy = (sum(seq_y * seq_y) / N) ** 0.5
    Fxy = sum(seq_x * seq_y) / N
    output = Fxy / (fxx * fyy)
    return output

# calculate DPCCA
def DPCCA_c(seq_0,seq_1,seq_2):  # The input is the detrended subsequence
    DCCA_matrix = np.full((3,3),1.)
    DCCA_matrix[0,1] = DCCA_c(seq_0,seq_1)
    DCCA_matrix[1,0] = DCCA_matrix[0,1]
    DCCA_matrix[0,2] = DCCA_c(seq_0,seq_2)
    DCCA_matrix[2,0] = DCCA_matrix[0,2]
    DCCA_matrix[1,2] = DCCA_c(seq_1,seq_2)
    DCCA_matrix[2,1] = DCCA_matrix[1,2]
    matrix_pinv = np.linalg.pinv(DCCA_matrix)
    result = (-1 * matrix_pinv[0,1])/((matrix_pinv[0,0] * matrix_pinv[1,1]) ** 0.5)
    return result

#--------------------------------Extract three time series overlapping periods----------------------------
# Input 2-dimensional (1 column) dataframe, output 1-dimensional array
def extract_same_time(series_1,series_2,series_3): 
    series_1_index = series_1.index
    series_2_index = series_2.index
    series_3_index = series_3.index
    
    series_01 = series_1[series_1_index.isin(series_2_index)]
    series_02 = series_2[series_2_index.isin(series_1_index)]
    
    series_01_index = series_01.index
    series_02_index = series_02.index
    
    array_1 = series_01[series_01_index.isin(series_3_index)].values.flatten()
    array_2 = series_02[series_02_index.isin(series_3_index)].values.flatten()
    array_3 = series_3[series_3_index.isin(series_01_index)].values.flatten()
    
    return array_1,array_2,array_3

# -----------------------------------------------
def DDPRR(series_0,series_1,series_2,step_min = 36,order = 1):
    seq_0,seq_1,seq_2 = extract_same_time(series_0,series_1,series_2)
    N = len(seq_0)
    step_max = N-1
    
    dcca_matrix = np.full([step_max - step_min + 1, N-step_min+1+1],np.nan)
    dpcca_matrix = np.full([step_max - step_min + 1, N-step_min+1+1],np.nan)
    ddprr_matrix = np.full([step_max - step_min + 1, N-step_min+1+1],np.nan)
    for step in range(step_min, step_max + 1):
        dcca_matrix[step-step_min,0] = step
        dpcca_matrix[step-step_min,0] = step
        ddprr_matrix[step-step_min,0] = step
        
        sub_seq_0_group = d_trend_step(seq_0,step,order)
        sub_seq_1_group = d_trend_step(seq_1,step,order)
        sub_seq_2_group = d_trend_step(seq_2,step,order)
        for sub_index in range(N-step+1):
            dcca_c = DCCA_c(sub_seq_0_group[sub_index,:],sub_seq_1_group[sub_index,:])
            dpcca_c = DPCCA_c(sub_seq_0_group[sub_index,:],sub_seq_1_group[sub_index,:],sub_seq_2_group[sub_index,:])
        
            dcca_matrix[step-step_min,sub_index + 1] = dcca_c
            dpcca_matrix[step-step_min,sub_index + 1] = dpcca_c
            ddprr_matrix[step-step_min,sub_index + 1] = (dcca_c-dpcca_c)/(dcca_c + 1)
               
    return dcca_matrix,dpcca_matrix,ddprr_matrix


if __name__ == "__main__":
    rootpath = r'F:\DCCA、DPCA\04-six-factors'
    stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
    factorlst = ['et0','bf','ndvi','isr','ntl','pop']

    start = time.time()
    for station in stationlst:
        meteo = pd.read_excel(os.path.join(rootpath,r'01-data\01-meteorological_data\{}_meteo.xlsx'.format(station)),
                                sheet_name = 'monthly',header = 0,index_col = 0)
        pre = meteo[['precipitation']]
        et0 = meteo[['ET0']]
        runoff = pd.read_excel(os.path.join(rootpath,r'01-data\02-runoff\{}_runoff.xlsx'.format(station)),
                                sheet_name = 'monthly',header = 0,index_col = 0)
        bf = pd.read_excel(os.path.join(rootpath,r'01-data\03-baseflow\{}_baseflow.xlsx'.format(station)),
                               sheet_name = 'monthly',header = 0,index_col = 0)
        ndvi = pd.read_excel(os.path.join(rootpath,r'01-data\04-NDVI\{}_NDVI.xlsx'.format(station)),
                               sheet_name = 'monthly',header = 0,index_col = 0)
        isr = pd.read_excel(os.path.join(rootpath,r'01-data\05-ISR\ISR.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        ntl = pd.read_excel(os.path.join(rootpath,r'01-data\06-NTL\NTL.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        pop = pd.read_excel(os.path.join(rootpath,r'01-data\07-POP\POP.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        
        sheet_count = 1
        for factor_index in range(len(factorlst)):
            factor = factorlst[factor_index]
            factor3 = []
            exec("factor3 = {}".format(factor))
            
            dcca_matrix,dpcca_matrix,ddprr_matrix = DDPRR(pre,runoff,factor3)
            
            if sheet_count == 1:
                with pd.ExcelWriter(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}_DCCA.xlsx'.format(station))) as writer:
                    pd.DataFrame(dcca_matrix).to_excel(writer, sheet_name = factor,header = False, index = False)
                with pd.ExcelWriter(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}_DPCCA.xlsx'.format(station))) as writer:
                    pd.DataFrame(dpcca_matrix).to_excel(writer, sheet_name = factor,header = False, index = False)
                with pd.ExcelWriter(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}_DDPRR.xlsx'.format(station))) as writer:
                    pd.DataFrame(ddprr_matrix).to_excel(writer, sheet_name = factor,header = False, index = False)
            else:
                with pd.ExcelWriter(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}_DCCA.xlsx'.format(station)),
                                    mode="a",engine="openpyxl") as writer:
                    pd.DataFrame(dcca_matrix).to_excel(writer, sheet_name = factor,header = False, index = False)
                with pd.ExcelWriter(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}_DPCCA.xlsx'.format(station)),
                                    mode="a",engine="openpyxl") as writer:
                    pd.DataFrame(dpcca_matrix).to_excel(writer, sheet_name = factor,header = False, index = False)
                with pd.ExcelWriter(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}_DDPRR.xlsx'.format(station)),
                                    mode="a",engine="openpyxl") as writer:
                    pd.DataFrame(ddprr_matrix).to_excel(writer, sheet_name = factor,header = False, index = False)
            sheet_count += 1
        end = time.time()
        print(station,':',end-start)
    print('ok')  
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            