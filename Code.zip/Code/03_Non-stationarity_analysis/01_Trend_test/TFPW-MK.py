# -*- coding: utf-8 -*-
"""
The TFPW-MK method was used to test the trend.

@author: Li Tongfang
"""

import os
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import norm

# ---------------partial autocorrelation coefficient----------------
import statsmodels.tsa.stattools as stattools
def default_pacf(ts, k=1):
    return stattools.pacf(ts, nlags=k)

# --------------- TFPW ---------------------------------------------
def TFPW(seq_old):      # input 1-dimensional array
    seq_old = seq_old.flatten()
    beta = stats.theilslopes(seq_old, np.arange(len(seq_old)))[0]
    seq_res = seq_old - beta * np.arange(len(seq_old))
    gama = default_pacf(seq_res,1)[1]
    seq_noise = np.zeros(len(seq_res))
    seq_noise[0] = seq_res[0]
    for i in range(1,len(seq_res)):
        seq_noise[i] = seq_res[i] - gama * seq_res[i-1]
    seq_new = seq_noise + beta * np.arange(len(seq_old))
    return seq_new

#-------------------------------MK--------------------------------
def mk(x, alpha=0.1):  #  1-alpha/2 is the confidence level
    n = len(x)
    s = 0
    for j in range(n - 1):
        for i in range(j + 1, n):
            s += np.sign(x[i] - x[j])
    unique_x, tp = np.unique(x, return_counts=True)
    g = len(unique_x)

    if n == g:
        var_s = (n * (n - 1) * (2 * n + 5)) / 18
    else:
        var_s = (n * (n - 1) * (2 * n + 5) - np.sum(tp * (tp - 1) * (2 * tp + 5))) / 18

    if n <= 10:
        z = s / (n * (n - 1) / 2)
    else:
        if s > 0:
            z = (s - 1) / np.sqrt(var_s)
        elif s < 0:
            z = (s + 1) / np.sqrt(var_s)
        else:
            z = 0

    p = 2 * (1 - norm.cdf(abs(z)))
    return z,p

## -------------------------calculation------------------------------------
# --------------------------Case 1--------------------------------
rootpath = r'F:\DCCA、DPCA\04-six-factors'
stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
value_z = []
for station in stationlst:
    data = pd.read_excel(os.path.join(rootpath,r'01-data\04-NDVI\{}_NDVI.xlsx'.format(station)),
                          sheet_name ='annual',header = 0,index_col = 0).values
    data_tfpw = TFPW(data)
    z,_ = mk(data_tfpw)
    value_z.append(z)


# --------------------------Case 2--------------------------------
# rootpath = r'F:\DCCA、DPCA\04-six-factors'
# value_z = []
# for i in range(5):
#     data = pd.read_excel(os.path.join(rootpath,r'01-data\05-ISR\ISR.xlsx'),
#                           sheet_name ='annual',header = 0,index_col = 0).values
#     data_tfpw = TFPW(data[:,i])
#     z,_ = mk(data_tfpw)
#     value_z.append(z)







