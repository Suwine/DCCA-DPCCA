function [yearchange,P,UtT,A,yearvector]=TFPW_Pettitt(QNQ,QLeng) 
%% Normalise and prepare for MK-test (Yue et al 2002)
yearvector=QNQ(:,1); 
WaterLevel=QNQ(:,2);
lWL=length(WaterLevel);

t=1:1:lWL;

% Normalise data according to Appendix 1 (Yue et al. 2002) 
MeanWL=mean(WaterLevel);
NormWL=WaterLevel/MeanWL; % mean value is 1

% Determine the slope of the trend in water level (Yue et al 2002 eq 17)
id=1; bCalc=NaN(lWL-1,1);
for j=2:lWL
    for l=1:j-1
        bCalc(id)=(NormWL(j)-NormWL(l))/(j-l); %calculate slope
        id=id+1;
    end
end
b=median(bCalc); %mean slope

% Detrend the normalised data (Yue et al, 2002, eq 19)
DetrWL=NormWL-(t*b)'; % Trend free or detrend
MDetWL=mean(DetrWL);

% Determine lag-k serial correlation coefficient (Yue et al, 2002, eq 14a)
k=1;            % because we calculate lag-1 serial correlation. 
sumAbove=0;
sumBelow=0;
for a=1:lWL-k;              % eq 14a, sum above line
    sumAbove=sumAbove+(DetrWL(a)-MDetWL)*(DetrWL(a+k)-MDetWL);
end

for a=1:lWL;                % eq 14a, sum below line
    sumBelow=sumBelow+((DetrWL(a)-MDetWL)^2);
end

r=(1/(lWL-k)*sumAbove)/(1/lWL*sumBelow);       % complete eq 14a

% Remove serial correlation from detrended data, Yue et al 2002, eq 20
NoCorrWL=NaN(1,lWL);
NoCorrWL(1)=DetrWL(1)-r*DetrWL(1);
for a=2:lWL;
    NoCorrWL(a)=DetrWL(a)-r*DetrWL(a-1);
end

% Add trend back to residual data
MKprepWLa=NoCorrWL+(b*t);
MKprepWL=MKprepWLa(1:lWL);


%% Pettitt-test
% test statistic UtT according to eq (5)
% using data from which serial correlation has been removed
UtT=zeros(1,lWL);
for t=1:lWL;
    for i=1:t;
        for j=t+1:lWL
            UtT(t)=UtT(t)+sign(MKprepWL(i)-MKprepWL(j));
        end
    end
end

KTabs = max(abs(UtT));
KTid = KTabs==abs(UtT);
KT =   UtT(KTid);
%yearvector=10;
yearchange=yearvector(KTid);
yearchange=yearchange(1);

% calculate rho
rho=exp((-6*KT.^2)/(lWL^3+lWL^2));
PP=1-rho;
[tt,ttt]=size(PP);
Maxt=max(tt,ttt);
if Maxt>1
    P=max(PP);
else
    P=PP;
end
%'Z=',ZMK
if lWL<QLeng
% 'Sub-Change-points=',yearchange
% 'Sub-KT=',KT
% 'Sub-P=',P
output=[yearchange KT P];
else
% 'Change-points=',yearchange
% 'KT=',KT
% 'P=',P
output=[yearchange KT P];
end
A=zeros(1,lWL);
for j=1:lWL
    A(j)=1-exp((-6*UtT(j).^2)/(lWL^3+lWL^2));
end
% figure 
% [AX,H1,H2]=plotyy(yearvector,UtT,yearvector,A,'bar','plot');
% title('Mann-Whitney-Pettitt test statistic');
% xlabel('Time / year');
% set(get(AX(1),'Ylabel'),'String','Statistic');
% set(get(AX(2),'Ylabel'),'String','Probility');
% set(H2,'color','r','LineStyle',':','marker','o','MarkerEdgeColor','r');
% legend('Statistic','Probility');
end
