clear
clc
[QN,headertxt]=xlsread('F:\DCCA��DPCA\04-six-factors\01-data\02-runoff\qinan_runoff.xlsx','annual');	% Input the data
[Leng,L]=size(QN);date=QN(:,1);data=QN(:,2);
%% TFPW-Pettitt
[Point,Pro]=TFPW_Pettitt(QN,Leng); 
m=Point-QN(1,1);
n=Point-QN(1,1)+2;
if Pro>0.9                      
    i=1;
    CP(i)=Point;
    QNB=QN(1:m,:);
    Leng1=size(QNB);
    [Point1,Pro1]=TFPW_Pettitt(QNB,Leng1);
   
         m1=Point1-QN(1,1);
         n1=Point1-QN(1,1)+2;
         if Pro1>0.9
         i=i+1;
         CP(i)=Point1;
         QNB1=QN(1:m1,:);
         Leng11=size(QNB);
         [Point11,Pro11]=TFPW_Pettitt(QNB1,Leng11);
         if Pro11>0.9
         i=i+1;
         CP(i)=Point11;
         end
         QNB2=QN(n1:m,:);
         Leng12=size(QNB2);
         [Point12,Pro12]=TFPW_Pettitt(QNB2,Leng12);
         if Pro12>0.9
         i=i+1;
         CP(i)=Point12;
         end
         end
    
    
    QNA=QN(n:Leng,:);
    Leng2=size(QNA);
    [Point2,Pro2]=TFPW_Pettitt(QNA,Leng2);
    
         m2=Point2-QN(1,1);
         n2=Point2-QN(1,1)+2;
         if Pro2>0.9                       
         i=i+1;
         CP(i)=Point2;
         QNA1=QN(n:m2,:);
         Leng21=size(QNA1);
         [Point21,Pro21]=TFPW_Pettitt(QNA1,Leng21);
         if Pro21>0.9
         i=i+1;
         CP(i)=Point21;
         end
         QNA2=QN(n2:Leng,:);
         Leng22=size(QNA2);
         [Point22,Pro22]=TFPW_Pettitt(QNA2,Leng22);
         if Pro22>0.9
          i=i+1;
          CP(i)=Point22;
         end
         end
end

[bn,bm]=size(CP);
for i=1:bm
    CPk(i)=CP(i)-QN(1,1)+1;
end
CPk=[1,CPk];
CPk=sort(CPk);
[bn,bm]=size(CPk);
CPk=[CPk,Leng];

j=0;
x=0;
RCP=[];PCP=[];
UtT_RCP=[];A_RCP=[];year_RCP=[];UtT_PCP=[];A_PCP=[];year_PCP=[];
for i=2:bm
    Lk=CPk(i+1)-CPk(i-1);
    QNk=QN(CPk(i-1):CPk(i+1),:);
    [Pointk,Prok,UtT,A,year]=TFPW_Pettitt(QNk,Lk);
    UtT1=zeros(1,length(QN))./0;UtT2=UtT1;A1=UtT1;A2=UtT1;year1=UtT1;year2=UtT1;
    if Prok>0.9
     if Pointk==CP(i-1)
        j=j+1;
        RCP(j)=CP(i-1);
        UtT1(1,1:length(UtT))=UtT;
        UtT_RCP=[UtT_RCP;UtT1];
        A1(1,1:length(A))=A;
        A_RCP=[A_RCP;A1];
        year1(1,1:length(year))=year;
        year_RCP=[year_RCP;year1];
     else
        x=x+1;
        PCP(x)=Pointk;
        UtT2(1,1:length(UtT))=UtT;
        UtT_PCP=[UtT_PCP;UtT2];
        A2(1,1:length(A))=A;
        A_PCP=[A_PCP;A2];
        year2(1,1:length(year))=year;
        year_PCP=[year_PCP;year2];
     end
    end
end
CCP=[RCP,PCP];
disp(['abrupt shift point=', num2str(CCP)])
%CP��The first detection of abrupt shift points��
%RCP,Abrupt shift points consistent with the results of the first inspection after verification��
%PCP,Abrupt shift points different from the first inspection result after verification��
%CCP,Final abrupt shift point
UtT_final=[UtT_RCP;UtT_PCP];A_final=[A_RCP;A_PCP];year_final=[year_RCP;year_PCP];
Pettitt_result=zeros(size(UtT_final,1).*3,size(UtT_final,2))./0;
for i=1:size(UtT_final,1)
    Pettitt_result((1:3)+(i-1).*3,:)=[year_final(i,:);UtT_final(i,:);A_final(i,:)];
end
Pettitt_result=Pettitt_result';
disp(['Statistical parameter query��Pettitt_result��year,statistics��frequency��'])




