# -*- coding: utf-8 -*-
"""
Drawing a heatmap plot based on DCCA results calculated by "D-DPRR.py".

@author: Li Tongfang
"""

import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def gaimao(data,n = 5):
    data_0 = data
    data_flat_0 = data_0.flatten()
    data_flat = data_flat_0[~np.isnan(data_flat_0)]
    data_sort = np.abs(np.sort(-data_flat))
    v_max = data_sort[n];v_min = data_sort[-(n+1)]
    v_top = data_sort[:n];v_bottom = data_sort[-n:]
    for vv_top in v_top:
        data[data == vv_top] = v_max
    for vv_bottom in v_bottom:
        data[data == vv_bottom] = v_min
    
    return data

rootpath = r'F:\DCCA、DPCA\04-six-factors'
stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
factorlst = ['et0']
methodlst = ['DCCA']

triangle = pd.read_excel(os.path.join(rootpath,r'05-Figure5\02-Figure5b\index_position.xlsx'),
                        sheet_name = 'triangle',header = None,index_col = None).values
diamond = pd.read_excel(os.path.join(rootpath,r'05-Figure5\02-Figure5b\index_position.xlsx'),
                        sheet_name = 'diamond',header = None,index_col = None).values
tri_index = np.where(np.isnan(triangle))
dia_index = np.where(np.isnan(diamond))

year_start_df = pd.read_excel(os.path.join(rootpath,r'05-Figure5\02-Figure5b\index_position.xlsx'),
                        sheet_name = 'start_year',header = 0,index_col = 0)
fignum = 1
for station in stationlst:
    for method in methodlst:
        for factor in factorlst:
            dataset = pd.read_excel(os.path.join(rootpath,r'03-DCCA+D-DPRR\{}.xlsx'.\
                                                 format(station+'_'+method)),
                                    sheet_name = factor,header = None,index_col = 0).values
            year_start = int(year_start_df.loc[[factor],[station]].iloc[0])
            dataset = dataset[:,1:]
            n_year = dataset.shape[0]/12
            n_year = int(n_year)
            dataset_year = np.full((n_year,n_year),np.nan)
            for i in range(n_year):
                for j in range(n_year):
                    if j == 0:
                        dataset_year[i,j] = np.mean(dataset[tri_index[0]+i*12,tri_index[1]])
                    else:
                        dataset_year[i,j] = np.mean(dataset[dia_index[0]+i*12,dia_index[1]+(j-1)*12])
             
            year = list(np.arange(year_start,year_start+n_year,1))
            timescale = list(np.flipud(np.arange(3,3+n_year,1)))
            dataset_year = np.flipud(dataset_year)
            dataset_year = gaimao(dataset_year)
            
            df_data = pd.DataFrame(columns = year,index = timescale)
            df_data.iloc[:] = dataset_year
            
            xlabels = list(np.arange(year_start,year_start+n_year,20)+6)
            xticks = list(np.arange(0,n_year,20)+6)
            ylabels = list(np.flipud(np.arange(3,3+n_year,20)))
            yticks = list(np.flipud(np.arange(n_year,0,-20)))
            
            sns.set_theme(style="white")
            plt.rcParams['axes.unicode_minus']=False
            plt.rcParams['font.sans-serif']=['Arial']
            font0 = {'xtick.labelsize' : 25,
                  'ytick.labelsize' : 25}
            plt.rcParams.update(font0)  
            plt.figure(fignum,figsize = [6,6],dpi = 800)
            g = sns.heatmap(df_data,vmax=1.0, vmin=0.0,
                        cmap=sns.diverging_palette(h_neg = 158,h_pos = 267,s = 71, l = 63, as_cmap=True),
                        square=True, linewidths=.5, cbar = False)
            plt.xticks(xticks, xlabels)
            plt.yticks(yticks, ylabels)
            plt.tick_params(axis='x',pad = 0.5)
            plt.tick_params(axis='y',pad = 0.5)
            
            for label in g.axes.get_xticklabels():
                label.set_rotation(0)
            for label in g.axes.get_yticklabels():
                label.set_rotation(0)
            plt.savefig(os.path.join(rootpath,r'05-Figure5\02-Figure5b\{}.tif'.format(station)),
                        dpi=800, bbox_inches='tight')
            fignum += 1









