# -*- coding: utf-8 -*-
"""
Calculating the MIC results between pairs of ET0, BF, NDVI, ISR, NTL and POP.

@author: 李同方
"""

import os
import numpy as np
import pandas as pd
from minepy import MINE

def MIC(seq_1,seq_2,alpha = 0.6,c = 5):
    mine = MINE(alpha, c)
    mine.compute_score(seq_1, seq_2)
    return mine.mic()

def extract_same_time2(series_1,series_2):
    series_1_index = series_1.index
    series_2_index = series_2.index
    
    series_01 = series_1[series_1_index.isin(series_2_index)].values.flatten()
    series_02 = series_2[series_2_index.isin(series_1_index)].values.flatten()
        
    return series_01,series_02

def MIC_extract(series_1,series_2):
    series_01,series_02 = extract_same_time2(series_1,series_2)
    mic_r = MIC(series_01,series_02)
    return mic_r

if __name__ == "__main__":
    rootpath = r'F:\DCCA、DPCA\04-six-factors'
    stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
    grouplst = [['et0','bf'],['et0','ndvi'],['et0','isr'],['et0','ntl'],['et0','pop'],
                ['bf','ndvi'],['bf','isr'],['bf','ntl'],['bf','pop'],
                ['ndvi','isr'],['ndvi','ntl'],['ndvi','pop'],
                ['isr','ntl'],['isr','pop'],
                ['ntl','pop']
                ]
    factorlst = ['et0','bf','ndvi','isr','ntl','pop']
    sheet_count = 1
    for station in stationlst:
        
        result = pd.DataFrame(index = factorlst,columns = factorlst)
        meteo = pd.read_excel(os.path.join(rootpath,r'01-data\01-meteorological_data\{}_meteo.xlsx'.format(station)),
                                sheet_name = 'monthly',header = 0,index_col = 0)
        et0 = meteo[['ET0']]
        runoff = pd.read_excel(os.path.join(rootpath,r'01-data\02-runoff\{}_runoff.xlsx'.format(station)),
                                sheet_name = 'monthly',header = 0,index_col = 0)
        bf = pd.read_excel(os.path.join(rootpath,r'01-data\03-baseflow\{}_baseflow.xlsx'.format(station)),
                               sheet_name = 'monthly',header = 0,index_col = 0)
        ndvi = pd.read_excel(os.path.join(rootpath,r'01-data\04-NDVI\{}_NDVI.xlsx'.format(station)),
                               sheet_name = 'monthly',header = 0,index_col = 0)
        isr = pd.read_excel(os.path.join(rootpath,r'01-data\05-ISR\ISR.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        ntl = pd.read_excel(os.path.join(rootpath,r'01-data\06-NTL\NTL.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        pop = pd.read_excel(os.path.join(rootpath,r'01-data\07-POP\POP.xlsx'),
                               sheet_name = 'monthly',header = 0,index_col = 0)[[station]]
        
        for group in grouplst:
            factor1 = []; factor2 = [];
            exec("factor1 = {}".format(group[0]))
            exec("factor2 = {}".format(group[1]))
            result.loc[[group[1]],[group[0]]] = MIC_extract(factor1,factor2)
        
        
        if sheet_count == 1:
            with pd.ExcelWriter(os.path.join(rootpath,r'05-Figure5\03-Figure5c\MIC_result.xlsx')) as writer:
                result.to_excel(writer, sheet_name = station)
        else:
            with pd.ExcelWriter(os.path.join(rootpath,r'05-Figure5\03-Figure5c\MIC_result.xlsx',
                                             mode="a",engine="openpyxl")) as writer:
                result.to_excel(writer, sheet_name = station)
        sheet_count += 1
       













