# -*- coding: utf-8 -*-
"""
Drawing a violin plot based on DCCA results calculated by "DPRR.py".

@author: Li Tongfang
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

rootpath = r'F:\DCCA、DPCA\04-six-factors'
stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
factorlst = ['et0']
methodlst = ['DCCA']

fignum = 1
for station in stationlst:
    
    for method in methodlst:
        
        data_dict = {}
        for factor in factorlst:
            data = pd.read_excel(os.path.join(rootpath,r'02-DCCA+DPRR\{}_DPRR.xlsx'.format(station)),
                     sheet_name = factor,header = 0)
            data_dict[factor] = data[method]
            
        data_draw = pd.DataFrame(data_dict)
        data_draw = data_draw.iloc[24:]
        
        plt.rcParams['axes.unicode_minus']=False 
        plt.rcParams['font.sans-serif']=['Arial']
        font0 = {'xtick.labelsize' : 25,
                  'ytick.labelsize' : 25}
        plt.rcParams.update(font0)    
    
        plt.figure(fignum,figsize = [6,4],dpi = 800)
        ax=plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        ax.spines['left'].set_color('#737373')
        ax.spines['bottom'].set_color('#737373')
        plt.tick_params(axis='both',
                colors='#737373',
                left = 'on',
                labelcolor='black')
        plt.tick_params(axis='x',
                labelcolor='white')
        
        figgrid = sns.violinplot(data=data_draw,
                                 color = (0.8925745768290236, 0.8907787440153258, 0.9406707842593988),
                                 scale="count",inner='box',
                                 width = 0.5
                                 )
        figgrid.axes.collections[0].set_edgecolor('#762a83')
        plt.ylim(0,1)
        plt.savefig(os.path.join(rootpath,r'05-Figure5\02-Figure5a\{}.tif'.format(station+'_'+method)),
            dpi=800, bbox_inches='tight')
        fignum += 1
























