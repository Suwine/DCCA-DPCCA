# -*- coding: utf-8 -*-
"""
Drawing a violin plot based on the absolute value of the DPRR results.

@author: Li Tongfang
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

rootpath = r'F:\DCCA、DPCA\04-six-factors'
stationlst = ['qinan','weijiabao','xianyang','zhangjiashan','zhuangtou']
factorlst = ['et0','bf','ndvi','isr','ntl','pop']
colorlst = ['#08519c','#006d2c','#252525','#d94801','#54278f','#a50f15']
colorlst_l = ['#deebf7','#e5f5e0','#f0f0f0','#fee6ce','#efedf5','#fee0d2']

fignum = 1
for station in stationlst:
       
    data_dict = {}
    for factor in factorlst:
        data = pd.read_excel(os.path.join(rootpath,r'02-DCCA+DPRR\{}_DPRR.xlsx'.format(station)),
                 sheet_name = factor,header = 0)
        data_method = data['DPRR']
        
        data_dict[factor] = data_method[:]
    data_draw = pd.DataFrame(data_dict)
    data_draw = data_draw.iloc[24:]
    data_draw = data_draw.abs()

    plt.rcParams['axes.unicode_minus']=False 
    plt.rcParams['font.sans-serif']=['Arial']
    font0 = {'xtick.labelsize' : 25,
              'ytick.labelsize' : 25}
    plt.rcParams.update(font0)

    plt.figure(fignum,figsize = [6,6],dpi = 800)
    ax=plt.gca()  
    ax.spines['right'].set_color('none')
    ax.spines['top'].set_color('none')
    ax.spines['left'].set_color('#737373')
    ax.spines['bottom'].set_color('#737373')
    plt.tick_params(axis='both',
            colors='#737373',
            left = 'on',
            labelcolor='black')
    plt.tick_params(axis='x',
            labelcolor='white')
    
    figgrid = sns.violinplot(data=data_draw,palette =colorlst_l,
                             inner = 'box',
                             scale="count",
                             width = 1.0,
                             )
    for i in range(6):
        figgrid.axes.collections[i*2].set_edgecolor(colorlst[i])
    plt.ylim(-0.1,0.3)
    plt.savefig(os.path.join(rootpath,r'06-Figure6\02-Figure6b\abs-{}.tif'.\
                             format(station+'_DPRR')),dpi=800, bbox_inches='tight')
    fignum += 1
























